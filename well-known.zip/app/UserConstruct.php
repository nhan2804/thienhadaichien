<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserConstruct extends Model
{
    protected $table="user_construct";
    protected $primaryKey="id_u_c";
}
