<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Research extends Model
{
    protected $table = 'research';
    protected $primaryKey = 'id_r';
}
