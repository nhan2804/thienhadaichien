<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MilitaryAttr extends Model
{
    protected $table="military_attr";
    protected $primaryKey="id_m_a";
}
