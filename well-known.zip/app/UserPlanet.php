<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserPlanet extends Model
{
    protected $table = 'user_planet';
    protected $primaryKey = 'id_u_p';
}
