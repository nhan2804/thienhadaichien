<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserResearch extends Model
{
    protected $table = 'user_research';
    protected $primaryKey = 'id_u_r';
}
