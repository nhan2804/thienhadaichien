<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Construct extends Model
{
    protected $primaryKey = 'id_c';
    protected $table = 'construction';
}
