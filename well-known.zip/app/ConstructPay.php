<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ConstructPay extends Model
{
    protected $primaryKey = 'id_c_pa';
    protected $table = 'construct_pay';
}
