<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ConstructPro extends Model
{
    protected $primaryKey = 'id_c_p';
    protected $table = 'construct_pro';
}
