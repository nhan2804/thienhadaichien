<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Galactic extends Model
{
    //]
    protected $primaryKey = 'id';
    protected $table = 'galactic';
    public $timestamps = false;
}
