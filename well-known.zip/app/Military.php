<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Military extends Model
{
    protected $table="military";
    protected $primaryKey="id_m";
}
