<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ConstructParam extends Model
{
    protected $primaryKey = 'id_c_pm';
    protected $table = 'construct_param';
}
