<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MilitaryActionController extends Controller
{
    //
}
