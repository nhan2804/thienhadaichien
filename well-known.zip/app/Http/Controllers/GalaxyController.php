<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class GalaxyController extends Controller
{
    //
}
