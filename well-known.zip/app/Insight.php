<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Insight extends Model
{
    protected $primaryKey = 'id_i';
    protected $table = 'insight';
}
