<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ConstructPercent extends Model
{
    protected $primaryKey = 'id_c_pe';
    protected $table = 'construct_percent';
}
