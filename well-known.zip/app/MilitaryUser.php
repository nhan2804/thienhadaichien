<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MilitaryUser extends Model
{
    protected $table="military_user";
    protected $primaryKey="id_m_u";
}
