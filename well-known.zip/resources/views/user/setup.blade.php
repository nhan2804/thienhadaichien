<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Đang load...</title>
</head>
<body>
	{{-- @foreach($pro as $k=>$v) --}}
	{{-- <input type="" value="{{$v->name_resource}} {{$v->value_p}} {{$v->unit_p}}" name=""> --}}
	{{-- @endforeach --}}
	{{-- <input type="text" value="{!!$pro!!}" name="" id=""> --}}
</body>
<script type="text/javascript">
	// sessionStorage.setItem("produce"
	// console.log({{$pro}});
</script>
</html>