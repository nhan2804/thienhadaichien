
<?php $__env->startSection('left-bar'); ?>
<ul class="p-0 list-menu">
    <li><a href="<?php echo e(URL::to('dashboard/headquarter/army')); ?>">Quân viễn chinh</a></li>
    <li><a href="<?php echo e(URL::to('dashboard/headquarter/defense')); ?>">Phòng thủ công trình</a></li>
    <li><a href="<?php echo e(URL::to('dashboard/headquarter/colony')); ?>">Trạm thuộc địa</a></li>
</ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<?php echo $__env->yieldContent('content'); ?>
	<h4>MỤC TIÊU</h4>
	<div>
        <input type="text">
        <button>Tấn công thần tốc</button>
	</div>
    <table class="table table-dark">
        <thead>
            <tr>
              <th scope="col">#ID</th>
              <th scope="col">Tên</th>
              <th scope="col">Location</th>
              <th scope="col">Hành động</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                
              <th scope="row"><?php echo e($v->id); ?></th>
              <td><?php echo e($v->name); ?></td>
              <td><?php echo e($v->location); ?></td>
              <td><a href="attack/<?php echo e($v->name); ?>?id=<?php echo e($v->id); ?>">Tấn công</a></td>
              
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
    </table>
	<div class="d-flex justify-content-end">
		<a class="btn btn-secondary" href="">ĐI ĐẾN</a>
	</div>
<div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\well-known\resources\views/user/attack/index.blade.php ENDPATH**/ ?>