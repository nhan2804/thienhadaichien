
<?php $__env->startSection('left-bar'); ?>
<ul class="p-0 list-menu">
    <li><a href="<?php echo e(URL::to('dashboard/headquarter/expeditionary-army')); ?>">Quân viễn chinh</a></li>
    <li><a href="<?php echo e(URL::to('dashboard/headquarter/defense')); ?>">Phòng thủ công trình</a></li>
    <li><a href="<?php echo e(URL::to('dashboard/headquarter/colony')); ?>">Trạm thuộc địa</a></li>
</ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<h4>BỘ CHỈ HUY / QUÂN VIỄN CHINH</h4>
	<i>Tất cả các quân đang bay ngoài không gian (kể cả tàu chở hàng)</i>
	<div>
		<table class="table table-dark">
            <thead>
                <td>Số lượng</td>
                <td>Mục tiêu</td>
				<td>Liên minh</td>
				<td>Trạng thái</td>
            </thead>
			<tbody>
                <?php $__currentLoopData = $army; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($v->quantity); ?></td>
                    <td>Hành tinh <?php echo e($v->location); ?></td>
                    <td>OMG</td>
                    <td class="text-success"><?php echo e($v->time_attack); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
		</table>
	</div>
<div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\well-known\resources\views/user/headquarter/expeditionary_army.blade.php ENDPATH**/ ?>