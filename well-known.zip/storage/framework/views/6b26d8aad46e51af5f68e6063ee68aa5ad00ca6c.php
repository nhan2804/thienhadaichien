
<?php $__env->startSection('left-bar'); ?>
<ul class="p-0 list-menu">
    <li><a href="<?php echo e(URL::to('dashboard/overview')); ?>">Do thám quỹ đạo</a></li>
    <li><a href="<?php echo e(URL::to('dashboard/news')); ?>">Đào tạo trinh thám</a></li>
    <li><a href="">Đào tạo phản gián</a></li>
</ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<h4>CƠ QUAN TÌNH BÁO</h4>
	<div>
		<table border style="width: 100%;text-align: center;">
			<tr>
				<td>Hành tinh</td>
				<td>Thủ lĩnh</td>
				<td>Tọa độ</td>
				<td>Liên minh</td>
				<td><i class="fas fa-eye"></i></td>
				<td><i class="fas fa-user-secret"></i></td>
			</tr>
			<tr>
				<td>Gold Gate</td>
				<td>Ngoc Nhan</td>
				<td>92.921.010</td>
				<td>OMG</td>
				<td>1,200</td>
				<td><a href="#">Gửi</a></td>
			</tr>
			<tr>
				<td>Gold Gate</td>
				<td>Ngoc Nhan</td>
				<td>92.921.010</td>
				<td>OMG</td>
				<td>1,200</td>
				<td><a href="#">Gửi</a></td>
			</tr>
		</table>
	</div>
	<div class="d-flex justify-content-end">
		<a href="#">Xem thêm</a>
	</div>
<div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\well-known\resources\views/user/intelligence_agencies/index.blade.php ENDPATH**/ ?>