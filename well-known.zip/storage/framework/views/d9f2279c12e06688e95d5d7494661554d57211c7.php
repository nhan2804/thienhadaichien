
<?php $__env->startSection('left-bar'); ?>
<ul class="p-0 list-menu">
	<li><a href="<?php echo e(URL::to('dashboard/headquarter/expeditionary-army')); ?>">Quân viễn chinh</a></li>
    <li><a href="<?php echo e(URL::to('dashboard/headquarter/defense')); ?>">Phòng thủ công trình</a></li>
    <li><a href="<?php echo e(URL::to('dashboard/headquarter/colony')); ?>">Trạm thuộc địa</a></li>
</ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	
	<h4>BỘ CHỈ HUY</h4>
	<div>
		<table border style="width: 100%;text-align: center;">
			
			<?php $__currentLoopData = $my_milis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($v->name_m); ?> : <?php echo e($v->quantity); ?></td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
		</table>

	</div>
	<div class="d-flex justify-content-end">
		<a class="btn btn-secondary" href="attack">ĐI ĐẾN</a>
	</div>
<div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\well-known\resources\views/user/headquarter/index.blade.php ENDPATH**/ ?>