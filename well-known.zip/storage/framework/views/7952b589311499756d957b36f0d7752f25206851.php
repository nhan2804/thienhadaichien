
<?php $__env->startSection('left-bar'); ?>
<ul class="p-0 list-menu">
    <li><a href="<?php echo e(URL::to('dashboard/overview')); ?>">Tổng quan</a></li>
    <li><a href="<?php echo e(URL::to('dashboard/news')); ?>">Tin tức</a></li>
    <li><a href="">Báo cáo</a></li>
    <li><a href="<?php echo e(URL::to('dashboard/build')); ?>">Xây dựng công trình</a></li>
    <li><a href="<?php echo e(URL::to('dashboard/military')); ?>">Xây dựng quân sự</a></li>
    <li><a href="<?php echo e(URL::to('dashboard/research')); ?>">Nghiên cứu</a></li>
    <li><a href="<?php echo e(URL::to('dashboard/headquarter')); ?>">Bộ chỉ Huy</a></li>
    <li><a href="<?php echo e(URL::to('dashboard/intelligence-agencies')); ?>">Cơ quan tình báo</a></li>
    <li><a href="<?php echo e(URL::to('dashboard/market')); ?>">Giao thương</a></li>
    <li><a href="#">Bộ ngoại giao</a></li>
    <li><a href="#">Bảng xếp hạng</a></li>
    <li><a href="#">Diễn đàn</a></li>
    <li><a href="#">Cài đặt</a></li>
    <li><a href="#">Thoát</a></li>
</ul>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div>
		<table border style="width: 100%;text-align: center;">
			<tr>
				<td>Thủ lĩnh</td>
				<td><b><?php echo e($user->fullname); ?></b></td>
				<td>Tài sản</td>
				<td>50,000</td>
			</tr>
			<tr>
				<td>Cấp bậc</td>
				<td>Lính</td>
				<td>Điểm</td>
				<td>1,000</td>
			</tr>
			<tr>
				<td>Hành tinh</td>
				<td>Ôn hòa</td>
				<td>Dân số</td>
				<td>1,2000</td>
			</tr>
			<tr>
				<td>Thứ hạng</td>
				<td>200/1900</td>
				<td>Chỗ ở</td>
				<td>9200</td>
			</tr>
		</table>
	</div>
	<h4>NHẬT BÁO HÀNH TINH</h4>
	<div>
		<table border style="width: 100%;text-align: center;">
			<tr>
				<td>Thời gian</td>
				<td>Loại hình</td>
				<td>Nội dung</td>
			</tr>
			<tr>
				<td>11/20/2021</td>
				<td>Nhà ở</td>
				<td>Xong</td>
			</tr>
			<tr>
				<td>11/20/2021</td>
				<td>Nhà ở</td>
				<td>Xong</td>
			</tr>
			<tr>
				<td>11/20/2021</td>
				<td>Nhà ở</td>
				<td>Xong</td>
			</tr>
		</table>
	</div>
	<div class="d-flex justify-content-end">
		<a href="#">Xem thêm</a>
	</div>
<div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp\htdocs\well-known\resources\views/user/notify/index.blade.php ENDPATH**/ ?>