<?php $arr = array("","<p>Bạn là một nhà lãnh đạo bẩm sinh, luôn muốn tự do suy nghĩ và hành động. Bạn là người có trách nhiệm với những nhiệm vụ được giao và những người mà bạn yêu quý. Một khi bạn quyết tâm làm một việc gì đó, bạn không cho phép bất cứ điều gì hoặc bất cứ ai cản đường bạn.<p>
<p>Đặc điểm:</p>
<p>- Bạn sáng tạo và luôn có tinh thần cầu tiến.</p>
<p>- Bạn tự lập và cần mẫn.</p>
<p>- Bạn can đảm và không sợ khó khăn để đạt được mục tiêu của mình.</p>
<p>- Bạn quan tâm đến hình ảnh của bản thân.</p>
<p>- Bạn muốn tự do, tự chủ trong công việc.</p>
<p>- Bạn là người có cá tính mạnh, tượng trưng cho những người tiên phong và cải cách. </p>
<p>- Bạn muốn mình trở thành người ảnh hưởng và ít nhờ sự hỗ trợ từ người khác.</p>
<p>- Bạn kiên định, thật khó khiến bạn thay đổi một khi bạn đã quyết định.</p>
<p>- Bạn tốt bụng và rộng lượng nhưng thường không thích thể hiện ra bên ngoài.</p>",
"Số ngày sinh cho thấy cách bạn quan sát, cảm nhận thế giới và những ấn tượng của người khác về bạn
<p>- Bạn hòa đồng, biết cách hợp tác và có tinh thần đồng đội tốt.
<p>- Bạn có biệt tài tìm kiếm giải pháp, bạn có thể nhìn rõ các khía cạnh của vấn đề với trực giác nhạy bén và tính công bằng của mình.
EOD",
"
Số đường đời 3 tượng trưng cho năng lượng, nhiệt huyết và cảm hứng. Bạn có khả năng tư duy, nhạy bén, lên kế hoạch và ghi nhớ. Số đường đời 3 gắn với sáng tạo, kết nối, thích được lắng nghe và có phong cách nghệ sĩ.
Đặc điểm:
- Bạn là người có xu hướng thiên về hoạt động xã hội.
- Bạn thích truyền cảm hứng cho những người khác.
- Bạn có tư chất của nhà tư vấn thiên bẩm, luôn nhìn thấy tiềm năng của người khác. - Bạn thích sự tự do và không thích làm những công việc thiếu tính sáng tạo.
- Bạn nhanh nhẹn và nhanh trí nên khi ai đó chậm chạp, có thể bạn sẽ dễ cáu giận.
- Bạn có lòng nhiệt thành và khả năng lôi cuốn người khác.
- Bạn hóm hỉnh, khôn khéo và trung dung.
- Bạn thích có được sự chú ý nổi bật giữa đám đông.
- Bạn cầu tiến, có sự am hiểu hiểu sâu sắc và chú trọng đến phát triển trí tuệ.
- Bạn biểu hiện là người học nhanh trong hầu hết lĩnh vực thiên về nghệ thuật.
- Bạn là người hào phóng và không quan tâm nhiều đến việc thu chi quá chi tiết.",
"Số “4” là con số của trí tuệ nên bạn sinh ra đã là 1 Người Thầy. Bạn thường nhìn đời với lăng kính của một trí thức và thích làm việc có kế hoạch.
Đặc điểm:
- Bạn ngăn nắp, trật tự, và kỷ luật,
- Bạn siêng năng và có khả năng tổ chức tốt.
- Bạn là một người thực tế, bạn biết đưa ra những giải pháp hợp lý để giải quyết những vấn đề của mình từng bước một.
- Bạn thường thích cách tiếp cận kiểu chính thống hơn kiểu trải nghiệm mạo hiểm phiêu lưu.
- Bạn luôn tìm kiếm sự thật của vấn đề.
- Gia đình là một phần không thể thiếu của bạn.
- Số “4” có nền tảng sống vững chãi, thường không bị ám ảnh bởi nhu cầu tiền tài: bạn chỉ là muốn có tài sản vừa đủ để đảm bảo tương lai.
- Bạn yêu cầu sự trung thực, đặc biệt là trong các mối quan hệ.
- Bạn là một người chân thành trong mối quan hệ và rất thành thật khi yêu.
- Khi học một thứ gì đó, bạn luôn hạ quyết tâm phải trở thành chuyên gia về nó - đó là lý do vì sao số “4” là những người thầy tuyệt vời.",
"Đường đời của bạn có rất nhiều sự thú vị. Bạn thích phiêu lưu, trải nghiệm và gặp gỡ những người bạn mới. Bạn mong muốn có một cuộc sống tự do như một chú chim bay lượn trên bầu trời để làm những điều mình thích. Bạn chán ghét sự đơn điệu, thích làm nhiều việc cùng lúc và háo hức với những điều mới mẻ trong cuộc sống.
Đặc điểm:
- Bạn mang trong mình bản tính vui vẻ và phóng khoáng.
- Bạn thích tự do, yêu phiêu lưu và khám phá và sống với mục tiêu theo đuổi được du lịch khắp mọi nơi.
- Bạn không chịu được sự nhàm chán và ràng buộc.
- Bạn có khả năng thu hút đám đông và sức hút kết nối tự nhiên.
- Bạn thích truyền cảm hứng, ảnh hưởng lên người khác bằng xúc cảm và năng lượng của mình.
- Bạn thường có trực giác rất tốt, với cảm xúc sâu sắc và tư duy nghệ thuật cao.
- Bạn thu hút và năng động nhất khi được tự do diễn đạt những gì mình đang ấp ủ.
- Bạn ủng hộ lối sống cuộc đời vui vẻ và cũng muốn người khác sống vui vẻ.
- Bạn không thích cảm giác bị qua mặt.
- Số “5” giàu lòng nhân ái, một khi thấy có sự bất công dù có thể không trực tiếp giúp được nhưng bạn luôn nghĩ cách tích cực để tác động lên người khác.
- Bạn là một người đa tài, khi bạn nỗ lực kỷ luật và tập trung, bạn có thể thành công ở mọi lĩnh vực bạn mong muốn.",
"Số Đường đời 6 là những “phụ huynh” bẩm sinh, người luôn quan tâm đến người khác dưới cái nhìn của bậc làm cha làm mẹ. Số “6” quan niệm rằng: Tình yêu và hôn nhân là không thể tách rời. Bạn tin rằng, để một gia đình tế bào khỏe mạnh, hạnh phúc, việc cần làm là dành nhiều thời gian hơn cho người thân thay vì sự tập trung bên ngoài.
Đặc điểm:
- Bạn là một người có tnh thần trách nhiệm cao.
- Bạn đề cao sự hòa thuận, hợp tác và đoàn kết trong gia đình.
- Bạn luôn muốn bảo bọc và thấu hiểu những người thân của mình một cách trọn vẹn.
- Với số “6”, nhà là nơi quan trọng nhất, nó chiếm một khoảng thời gian khá lớn của bạn.
- Bạn đầy lòng yêu thương, bao dung và rất ghét sự bất công.
- Bạn xuất sắc trong các lĩnh vực liên quan đến sáng tạo cũng như khả năng chăm sóc người khác.
- Bạn có sức hút tự nhiên mãnh liệt không thể cưỡng lại.
- Số “6” cần có sự nghiệp riêng của mình, bởi vì bạn khó mà làm việc dưới trướng người khác (do đặc tính tư duy của bậc cha mẹ).
- Bạn luôn trung thành và đáng tin cậy trong các mối quan hệ.
- Người khác tin tưởng bạn vì bạn là một người an toàn và biết giữ bí mật.
Một điều thú vị là bạn thường hay động lòng trắc ẩn, nhưng một khi đã không thích hoặc không thoải mái với mối quan hệ của mình bạn sẽ tỏ ra vẻ lạnh lùng.","7","8","9","10");
?> 